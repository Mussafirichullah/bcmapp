class ApiProvider {
  static var api = "http://140.82.39.29/api/";  //TODO:: Update to live url
}
