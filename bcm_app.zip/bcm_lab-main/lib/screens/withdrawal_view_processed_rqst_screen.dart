import 'dart:convert' as convert;
import 'dart:io';

import 'package:BCMHoldings/network/api_provider.dart';
import 'package:BCMHoldings/widgets/withdrawals_widgets/withdrawal_history.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class WithdrawalViewProcessedReqstScreen extends StatefulWidget {
  static const routeName = '/withdrawalViewProcessed';

  @override
  _WithdrawalViewProcessedReqstScreenState createState() =>
      _WithdrawalViewProcessedReqstScreenState();
}

class _WithdrawalViewProcessedReqstScreenState
    extends State<WithdrawalViewProcessedReqstScreen> {
  List<dynamic> withdrawals;
  bool isLoading = false;

  Future<void> getWithdrawalData() async {
    setState(() {
      isLoading = true;
    });

    final SharedPreferences sharedPrefs = await SharedPreferences.getInstance();
    var token = sharedPrefs.getString("token") ?? null;
    var response =
        await http.get(ApiProvider.api + 'withdrawalsview', headers: {
      HttpHeaders.contentTypeHeader: "application/json",
      HttpHeaders.acceptHeader: "application/json",
      HttpHeaders.authorizationHeader: "Bearer $token"
    });
    var jsonResponse = convert.jsonDecode(response.body);
    if (jsonResponse["data"]["status"] == "success") {
      setState(() {
        withdrawals = jsonResponse["data"]["data"];
        if (withdrawals.isNotEmpty) {
          withdrawals = withdrawals
              .where((withdrawal) => withdrawal['status'] == 'proccessed')
              .toList();
        }
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    getWithdrawalData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: isLoading
            ? Center(child: CircularProgressIndicator())
            : ListView(
                children: <Widget>[
                  Padding(padding: EdgeInsets.only(top: 10)),
                  WithdrawalHistoryWidget(withdrawals: withdrawals)
                ],
              ));
  }
}
