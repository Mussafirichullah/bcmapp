import 'dart:convert';
import 'dart:io';

import 'package:BCMHoldings/network/api_provider.dart';
import 'package:BCMHoldings/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

import 'package:toast/toast.dart';

class ResetPassword extends StatefulWidget {
  static const routeName = '/reset_password';

  @override
  _ResetPasswordState createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {
  var emailController = TextEditingController();
  bool isLoading = false;

  Future<void> resetPassword() async {
    setState(() {
      isLoading = true;
    });
    var response = await http.post(
      ApiProvider.api + 'forgot_password',
      headers: {
        HttpHeaders.contentTypeHeader: "application/json",
        HttpHeaders.acceptHeader: "application/json"
      },
      body: jsonEncode(<String, String>{'email': emailController.text}),
    );
    var jsonResponse = convert.jsonDecode(response.body);
    if (jsonResponse["data"]["status"] == "success") {
      setState(() {
        isLoading = false;
        print(jsonResponse["data"]["message"]);
        showAlertDialog(jsonResponse["data"]["message"]);
      });
    }
  }

  showAlertDialog(message) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Success",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
            content: Text(message,
                style: TextStyle(color: Colors.black, fontSize: 16)),
            actions: <Widget>[
              FlatButton(
                onPressed: () {
                  Navigator.of(context).pushNamed(LoginScreen.routeName);
                },
                child: Text("OK"),
              )
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).viewInsets.top + 60,
          right: 15,
          left: 15,
          bottom: 10,
        ),

        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: (mediaQuery.height) * 0.20,
                child: Image.asset(
                  'assets/images/LogoWhite.png',
                  fit: BoxFit.cover,
                ),
              ),
              Container(
                alignment: Alignment.centerLeft,
                height: (mediaQuery.height) * 0.2,
                child: Text(
                  'Forgot Password?',
                  style: TextStyle(
                    color: Color.fromRGBO(255, 149, 0, 1),
                  ),
                ),
              ),
              Container(
                //alignment: Alignment.centerRight,
                //height: (mediaQuery.height) * 0.2,
                child: Text(
                  'Enter the email address you used when you registered and we will send you temporary password.',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(
                    color: Colors.white,
                  ),
                ),
                controller: emailController,
                keyboardType: TextInputType.visiblePassword,
                onSubmitted: (_) => null,
              ),
              Container(
                alignment: Alignment.centerRight,
                height: 100,
                child: FlatButton(
                  onPressed: () {
                    if (emailController.text != "") {
                      resetPassword();
                    } else {
                      Toast.show("Make sure email input is not empty", context,
                          duration: Toast.LENGTH_LONG, gravity: Toast.BOTTOM);
                    }
                  },
                  child: Text('Reset'),
                  textColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
        // ],
        // ),
      ),
    );
  }
}
