import 'package:flutter/material.dart';

class Help extends StatelessWidget {
  static const routeName = '/help';

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}