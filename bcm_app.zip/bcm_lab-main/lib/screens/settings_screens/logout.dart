import 'package:flutter/material.dart';

class Logout extends StatelessWidget {
  static const routeName = '/logout';

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}