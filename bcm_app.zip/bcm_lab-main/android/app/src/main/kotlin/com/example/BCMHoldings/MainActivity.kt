package com.example.BCMHoldings

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
